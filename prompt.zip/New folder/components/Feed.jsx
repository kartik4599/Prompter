"use client";
import axios from "axios";
import React, { useEffect, useState } from "react";
import PromptCard from "./PromptCard";
import { useRouter } from "next/navigation";

const PromptCardList = ({ data, handleTagClick, HandlerProfileClick }) => {
  return (
    <div className="mt-10 prompt_layout flex-wrap">
      {data.map((post) => (
        <PromptCard
          key={post._id}
          post={post}
          handleTagClick={handleTagClick}
          HandlerProfileClick={HandlerProfileClick}
        />
      ))}
    </div>
  );
};

const Feed = () => {
  const [searchText, setSearchText] = useState("");
  const [post, setPost] = useState([]);
  const router = useRouter();
  const handleSearchChange = async () => {
    const { data } = await axios.get(`/api/prompt/search?query=${searchText}`);
    console.log({ data });
    setPost(data);
  };

  const handleTagClick = async (query) => {
    setSearchText(query);
    const { data } = await axios.get(`/api/prompt/search?query=${query}`);
    console.log({ data });
    setPost(data);
  };

  const HandlerProfileClick = async (id) => {
    console.log({ id });
    router.push(`/profile/${id}`);
  };

  const fetchPost = async () => {
    const { data } = await axios.get("/api/prompt");
    if (data) {
      console.log({ data });
      setPost(data);
    }
  };

  useEffect(() => {
    fetchPost();
  }, []);

  useEffect(() => {
    if (searchText.length === 0) {
      fetchPost();
    }
  }, [searchText]);

  return (
    <section className="feed">
      <form className="relative w-full flex-center">
        <input
          type="text"
          placeholder="Search for a tag or a username"
          value={searchText}
          onChange={(e) => {
            setSearchText(e.target.value);
            handleSearchChange();
          }}
          required
          className="search_input"
        />
      </form>
      <PromptCardList
        data={post}
        handleTagClick={handleTagClick}
        HandlerProfileClick={HandlerProfileClick}
      />
    </section>
  );
};

export default Feed;
