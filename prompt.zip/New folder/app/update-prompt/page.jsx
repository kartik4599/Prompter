"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Form from "@components/Form";
import axios from "axios";
import "supports-color";

const EditPrompt = () => {
  const router = useRouter();
  const searchParams = useSearchParams();
  const promptId = searchParams.get("id");
  const [submitting, setSubmitting] = useState(false);
  const [post, setPost] = useState({ prompt: "", tag: "" });

  const updatePrompt = async (e) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      if (!post.prompt) {
        return;
      }

      const { data } = await axios.patch(`/api/prompt/${promptId}`, {
        prompt: post.prompt,
        tag: post.tag,
      });
      console.log({ data });

      if (data) {
        router.push("/");
        console.log("data", data);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setSubmitting(false);
    }
  };

  const fetchPromptById = async () => {
    try {
      const { data } = await axios.get(`/api/prompt/${promptId}`);
      console.log({ data, k: "sad" });
      setPost({ prompt: data.prompt, tag: data.tag });
    } catch (e) {}
  };

  useEffect(() => {
    fetchPromptById();
  }, [promptId]);

  return (
    <Form
      type="Edit"
      post={post}
      setPost={setPost}
      submitting={submitting}
      handleSubmit={updatePrompt}
    />
  );
};

export default EditPrompt;
