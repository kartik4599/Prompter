"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Profile from "@components/Profile";
import axios from "axios";

const page = () => {
  const { data: session } = useSession();
  const [posts, setPosts] = useState([]);
  const router = useRouter();

  const HandleEdit = (post) => {
    console.log(post, "edit");
    router.push(`/update-prompt?id=${post._id}`);
  };

  const HandlerDelete = async (post) => {
    const hasConfirmed = confirm("Are you sure you want to delete this propmt");

    if (hasConfirmed) {
      const { data } = await axios.delete(`/api/prompt/${post._id}`);

      if (data) {
        setPosts(posts.filter((p) => p._id !== post._id));
      }
    }
  };

  const fetchPost = async () => {
    const { data } = await axios.get(`/api/users/${session.user.id}/posts`);

    if (data) {
      setPosts(data);
      console.log({ data });
    }
  };
  
  useEffect(() => {
    if (session?.user?.id) fetchPost();
  }, []);

  return (
    <Profile
      name="My Profile"
      desc="Welcome to ypur personalized profile page"
      data={posts}
      HandleEdit={HandleEdit}
      HandlerDelete={HandlerDelete}
    />
  );
};

export default page;
