"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import Profile from "@components/Profile";
import axios from "axios";
import { useRouter, useParams } from "next/navigation";

const page = () => {
  const { data: session } = useSession();
  const [posts, setPosts] = useState([]);
  const [user, setUser] = useState([]);
  const { id } = useParams();
  const router = useRouter();

  const fetchPost = async () => {
    const { data } = await axios.get(`/api/users/${id}/posts`);

    if (data) {
      setPosts(data);
      console.log({ data });
    }
  };

  useEffect(() => {
    if (id) {
      fetchPost();
    }
  }, [id]);

  return (
    <Profile
      name={posts[0]?.creator.username}
      desc="Welcome to profile page"
      data={posts}
    />
  );
};

export default page;
