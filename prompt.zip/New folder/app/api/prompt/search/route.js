import Prompt from "@models/propmt";
import { connectToDB } from "@utils/database";

export const GET = async (req, res) => {
  try {
    await connectToDB();

    const query = req.url.split("?")[1].split("=")[1];

    let propmts;
    if (query) {
      const keyword = {
        $or: [
          { prompt: { $regex: query, $options: "i" } },
          { tag: { $regex: query, $options: "i" } },
          { "creator.name": { $regex: query, $options: "i" } },
        ],
      };
      propmts = await Prompt.find().populate("creator").find(keyword);
    } else {
      propmts = await Prompt.find().populate("creator");
    }

    return new Response(JSON.stringify(propmts), { status: 200 });
  } catch (e) {
    console.log(e);
    return new Response("fail to fetch all prompts", { status: 500 });
  }
};
