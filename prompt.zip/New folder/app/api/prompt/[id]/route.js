import Prompt from "@models/propmt";
import { connectToDB } from "@utils/database";

export const GET = async (req, { params }) => {
  try {
    await connectToDB();
    const propmt = await Prompt.findById(params.id).populate("creator");

    if (!propmt) return new Response("Prompt not found", { status: 404 });

    return new Response(JSON.stringify(propmt), { status: 200 });
  } catch (e) {
    return new Response("failed to fetch all prompts", { status: 500 });
  }
};

export const PATCH = async (req, { params }) => {
  try {
    const { prompt, tag } = await req.json();

    await connectToDB();
    const existingPropmt = await Prompt.findById(params.id).populate("creator");

    if (!existingPropmt)
      return new Response("Prompt not found", { status: 404 });

    existingPropmt.prompt = prompt;
    existingPropmt.tag = tag;
    existingPropmt.save();

    return new Response(JSON.stringify(existingPropmt), { status: 200 });
  } catch (e) {
    return new Response("failed to update prompt", { status: 500 });
  }
};

export const DELETE = async (req, { params }) => {
  try {
    await connectToDB();
    const existingPropmt = await Prompt.findByIdAndRemove(params.id);

    if (!existingPropmt)
      return new Response("Prompt not found", { status: 404 });

    return new Response(JSON.stringify(existingPropmt), { status: 200 });
  } catch (e) {
    console.log(e);
    return new Response("failed to update prompt", { status: 500 });
  }
};
