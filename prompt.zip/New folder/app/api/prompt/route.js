import Prompt from "@models/propmt";
import { connectToDB } from "@utils/database";

export const GET = async (req, res) => {
  try {
    await connectToDB();

    const propmts = await Prompt.find().populate("creator");

    return new Response(JSON.stringify(propmts), { status: 200 });
  } catch (e) {
    console.log(e);
    return new Response("fail to fetch all prompts", { status: 500 });
  }
};
